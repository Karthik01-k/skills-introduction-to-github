print("Output:",
      "".join([i for i in str(input("Input: ")) if i.lower() not in "aeiou"])
      )
