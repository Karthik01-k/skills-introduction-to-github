print(float(eval(input("Expression: "))))
