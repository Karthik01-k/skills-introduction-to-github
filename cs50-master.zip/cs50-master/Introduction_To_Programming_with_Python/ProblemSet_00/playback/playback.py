print("...".join(str(input()).split(" ")))
