print("E:", int(input("m: ")) * (300000000 ** 2))
