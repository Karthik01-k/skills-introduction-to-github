print(str(input()).replace(":)", "🙂").replace(":(", "🙁"))
