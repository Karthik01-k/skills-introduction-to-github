inp = str(input())
print(inp.lower())
