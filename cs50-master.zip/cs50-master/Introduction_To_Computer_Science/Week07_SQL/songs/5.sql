SELECT AVG(energy) AS average_energy FROM songs;
